package com.technosignia.azown.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.technosignia.azown.entity.Property;
import com.technosignia.azown.repository.PropertyRepository;

@Service
public class PropertyService {

	@Autowired
	PropertyRepository propertyrepo;
	
	public List<Property> getAllPropertyDetails(){
		return propertyrepo.findAll();
	}
	
      public Property createProperty(Property property) {
		return propertyrepo.save(property);
	}
      
      public Property updatePropertyDetails( Property property ,Long id) {
    	  
    	  Optional<Property> optional=propertyrepo.findById(id);
    	  Property propertyDetails=optional.get();
    	  
    	  if(propertyDetails!=null) {
    		  
    		  if(property.getAddress()!=null) {
    			  propertyDetails.setAddress(property.getAddress());
    		  }
    		  if(property.getAmenities() !=null) {
    			  propertyDetails.setAmenities(property.getAmenities());  
    		  } 
    		  if(property.getCarpetArea() !=null) {
    			  propertyDetails.setCarpetArea(property.getCarpetArea());
    		  }
            if(property.getConfig() !=null) {
            	propertyDetails.setConfig(property.getConfig());
    		  }
            if(property.getName() !=null) {
            	propertyDetails.setName(property.getName());
  		  }
            if(property.getPropertyAge() !=null) {
            	propertyDetails.setPropertyAge(property.getPropertyAge());
  		  }
            if(property.getRentalPrice() !=null) {
            	propertyDetails.setRentalPrice(property.getRentalPrice());
  		  }
            if(property.getSellingPrice() !=null) {
            	propertyDetails.setSellingPrice(property.getSellingPrice());
  		  }
    	  }
		return propertyrepo.save(propertyDetails);
  		
  	}
}
