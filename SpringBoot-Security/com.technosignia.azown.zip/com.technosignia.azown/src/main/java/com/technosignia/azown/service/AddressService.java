package com.technosignia.azown.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.technosignia.azown.entity.Address;
import com.technosignia.azown.repository.AddressRepository;
@Service
public class AddressService {

	@Autowired
	AddressRepository  addressRepo;
	
	public List<Address> getAllAddress(){
		return addressRepo.findAll();
	}
	
	public Address createAddress(Address  address) {
		return addressRepo.save(address);
	}
	
	public void removeAddress(Long id) {
		
		addressRepo.deleteById(id);
		}
	
	public Address updateAddress(Address address,Long id) {
		Optional<Address> optional=addressRepo.findById(id);
		Address addressDetails=optional.get();
		if(optional != null) {
			
			
			if(address.getCity()!=null) {
				addressDetails.setCity(address.getCity());
			}
			if(address.getPincode()!=null) {
				addressDetails.setPincode(address.getPincode());
			}
			if(address.getStreet1()!=null) {
				addressDetails.setStreet1(address.getStreet1());
			}
			  
				}
		return addressRepo.save(addressDetails);
	}
	
   public Address getAddressById(Long id) {
		
			Optional<Address> address=	addressRepo.findById(id);
			return address.get();
	}
	
	}
