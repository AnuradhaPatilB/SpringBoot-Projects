package com.technosignia.azown.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;

@Entity
public class Property {

	@Id
	private Long id;
	
	private String name;
	private String config;
	private String amenities;
	private String sellingPrice;
	private String rentalPrice;
	private String carpetArea;
	private Long propertyAge;
    @OneToOne
	private Address address;
	
	public Property() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Property(Long id, String name, String config, String amenities, String sellingPrice, String rentalPrice,
			String carpetArea, Long propertyAge, Address address) {
		super();
		this.id = id;
		this.name = name;
		this.config = config;
		this.amenities = amenities;
		this.sellingPrice = sellingPrice;
		this.rentalPrice = rentalPrice;
		this.carpetArea = carpetArea;
		this.propertyAge = propertyAge;
	
		this.address = address;
	}



	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getConfig() {
		return config;
	}
	public void setConfig(String config) {
		this.config = config;
	}
	public String getAmenities() {
		return amenities;
	}
	public void setAmenities(String amenities) {
		this.amenities = amenities;
	}
	public String getSellingPrice() {
		return sellingPrice;
	}
	public void setSellingPrice(String sellingPrice) {
		this.sellingPrice = sellingPrice;
	}
	public String getRentalPrice() {
		return rentalPrice;
	}
	public void setRentalPrice(String rentalPrice) {
		this.rentalPrice = rentalPrice;
	}
	public String getCarpetArea() {
		return carpetArea;
	}
	public void setCarpetArea(String carpetArea) {
		this.carpetArea = carpetArea;
	}
	public Long getPropertyAge() {
		return propertyAge;
	}
	public void setPropertyAge(Long propertyAge) {
		this.propertyAge = propertyAge;
	}
	
}
