package com.technosignia.azown.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Address {

	@Id
	private Long id;
	private String street1;
	private String city;
	private Long pincode;
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Address(Long id, String street1, String city, Long pincode) {
		super();
		this.id = id;
		this.street1 = street1;
		this.city = city;
		this.pincode = pincode;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getStreet1() {
		return street1;
	}
	public void setStreet1(String street1) {
		this.street1 = street1;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public Long getPincode() {
		return pincode;
	}
	public void setPincode(Long pincode) {
		this.pincode = pincode;
	}
	
}
