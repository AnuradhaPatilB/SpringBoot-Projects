package com.technosignia.azown.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.technosignia.azown.entity.Owner;
import com.technosignia.azown.service.OwnerService;

@RestController
@RequestMapping("/owner")
public class OwnerController {

	@Autowired
	OwnerService ownerService;
	
	@PostMapping("/ownerData")
	public Owner createOwner(@RequestBody Owner owner) {
		return ownerService.createOwner(owner);
	}
	
	 @GetMapping("/details")
	
	public List<Owner> getAllOwner(){
		return ownerService.getAllOwner();
	}
	
	@DeleteMapping("/{id}")
	public String deleteById(@PathVariable Long id) {
		ownerService.deleteById(id);
		return "Owner deleted Sucessfully!";
	}
	@PutMapping("/{id}")
	public Owner updateOwnerDetails(@RequestBody Owner owner, @RequestParam Long id) {
		
		return ownerService.updateOwnerDetails(owner,id);
	}
	
	@GetMapping("/{id}")
	public Owner getOwnerById(@PathVariable Long id) {
		return ownerService.getOwnerById(id);
	}
}
