package com.technosignia.azown.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.technosignia.azown.entity.Property;
import com.technosignia.azown.service.PropertyService;

@RestController
public class PropertyController {

//	@Autowired
//	PropertyService propertyService;
//	
//	@GetMapping("/property")
//	public List<Property> getAllPropertyDetails(){
//		return propertyService.getAllPropertyDetails();
//	}
//	
//	@PostMapping("/property")
//	public Property createProperty(@RequestBody Property property) {
//		return propertyService.createProperty(property);
//	}
//	
//	@PutMapping("/property")
//	public Property updatePropertyDetails(@RequestBody Property property ,@RequestParam Long id) {
//		return propertyService.updatePropertyDetails(property, id);
//	}
}
