package com.technosignia.azown.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.technosignia.azown.entity.Owner;
import com.technosignia.azown.repository.OwnerRepository;

@Service
public class OwnerService {

	@Autowired
	OwnerRepository ownerRepo;
	
	public Owner createOwner(Owner owner) {
		
		return ownerRepo.save(owner);
	}
	
	public Owner getOwnerById(Long id) {
		
		       Optional<Owner> optional=   ownerRepo.findById(id);
		       Owner owner=optional.get();
		return owner;
				
	}
	
	public List<Owner> getAllOwner(){
		
		return ownerRepo.findAll();
	}
	
	public void deleteById(Long id) {
		ownerRepo.deleteById(id);
	}
	
    public Owner updateOwnerDetails( Owner owner ,Long id) {
		
    	   Optional<Owner> optional= ownerRepo.findById(id);
    	   Owner details=optional.get();
    	   if(optional != null) {
    		   
    		   if(owner.getName()!=null) {
    			 details.setName(owner.getName()); 
    		   }
    		   if(owner.getEmail()!=null) {
      			 details.setEmail(owner.getEmail()); 
      		   }
    		   if(owner.getContact()!=null) {
      			 details.setContact(owner.getContact()); 
      		   }
    		   if(owner.getAddress()!=null) {
    			   details.setAddress(owner.getAddress());
    		   }
    		   if(owner.getProperties()!=null) {
    			   details.setProperties(owner.getProperties());
    		   }
    	   }
		return ownerRepo.save(details) ;
	}
    
    
    
}
