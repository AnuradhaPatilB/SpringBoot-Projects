package com.technosignia.azown.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.technosignia.azown.entity.Address;
import com.technosignia.azown.service.AddressService;

@RestController
public class AddressController {

	@Autowired
	AddressService addressService;
	
//	@GetMapping("/address")
//	public List<Address> getAllAddress(){
//	return addressService.getAllAddress();	
//	}
//	
//	@PostMapping("/address")
//	public Address createAddress(@RequestBody Address address) {
//		return addressService.createAddress(address);
//		
//	}
//	@DeleteMapping("/address")
//	public String removeAddress(@RequestParam Long id) {
//		addressService.removeAddress(id);
//	 return "Address Deleted SucessFully!";	
//	}
//	@PutMapping("/address")
//	public Address updateAddress(@RequestBody Address address, @RequestParam Long id) {
//		return addressService.updateAddress(address, id);
//	}
//	@GetMapping("/address")
//	public Address getAddressById(@RequestParam Long id) {
//		return addressService.getAddressById(id);
//	}
}

















